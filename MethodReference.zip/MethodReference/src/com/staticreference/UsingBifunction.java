package com.staticreference;

import java.util.function.BiFunction;

public class UsingBifunction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BiFunction<Integer, Integer, Integer> adder = BifunctionImpl::add;
		int result = adder.apply(10, 20);
		System.out.println(result);
	}
}
