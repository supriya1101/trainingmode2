package com.staticreference;

public class StaticReference {
	public static void ThreadStatus() {
		System.out.println("Without usiong bifunction");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread t2 = new Thread(StaticReference::ThreadStatus);
		t2.start();
	}
}
