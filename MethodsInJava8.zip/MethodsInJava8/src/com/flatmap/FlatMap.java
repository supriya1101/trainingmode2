package com.flatmap;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class FlatMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> teamIndia = Arrays.asList("Virat", "Dhoni", "Jadeja");
		List<String> teamAustralia = Arrays.asList("Warner", "Watson", "Smith");
		List<String> teamEngland = Arrays.asList("Alex", "Bell", "Broad");

		List<List<String>> playersInWorldCup2016 = new ArrayList<>();
		playersInWorldCup2016.add(teamIndia);
		playersInWorldCup2016.add(teamAustralia);
		playersInWorldCup2016.add(teamEngland);
		List<String> listOfAllPlayers = new ArrayList<>();

		for (List<String> team : playersInWorldCup2016) {
			for (String name : team) {
				listOfAllPlayers.add(name);
			}
		}

		System.out.println("Players playing in world cup 2016");
		System.out.println(listOfAllPlayers);

		// Now let's do this in Java 8 using FlatMap
		List<String> flatMapList = playersInWorldCup2016
						.stream()
						.flatMap(pList -> pList.stream())
						.collect(Collectors.toList());

		System.out.println("List of all Players using Java 8");
		System.out.println(flatMapList);

	}

}
