package com.reduce;

import java.util.Arrays;
public class Reduce {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] myArray = { "this ", "is ", "a ", "sentence " };
		String result = Arrays.stream(myArray)
							  .reduce(" ", (a, b) -> a + b);
		System.out.println(result);

	}

}
