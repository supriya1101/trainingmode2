package com.Toarray;

import java.util.ArrayList;
import java.util.Arrays;

public class ToArray {

	public static void main(String[] args) {

		/*
		 * String lines = "i love my country";
		 * 
		 * // split by space, uppercase, and convert to Array String[] result =
		 * Arrays.stream(lines.split("\\s+")) .map(String::toUpperCase)
		 * .toArray(String[]::new);
		 * 
		 * for (String s : result) { System.out.println(s); }
		 */
		ArrayList<Integer> l = new ArrayList<Integer>();
		l.add(10);
		l.add(20);
		l.add(30);
		l.add(0);
		l.add(5);
		Integer[] i = l.stream().toArray(Integer[]::new);
		for (Integer i1 : i) {
			System.out.println(i1);
		}
	}

}