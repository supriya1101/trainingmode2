package com.demo.Internationalization;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class WelcomeController {
	
	 @RequestMapping(value= "/supriya", method= RequestMethod.GET)
	public ModelAndView initView() {
        ModelAndView modelview = new ModelAndView();
        modelview.addObject("welcome_msg", "Internationalization Example Using Spring Mvc ");      
        modelview.setViewName("welcome");
        return modelview;
    }
}

